Made in java version "1.8.0_161".
Requires java 7+ for java.nio library

Discussed with other student:
Joseph Law

Sources used:
http://eddmann.com/posts/depth-first-search-and-breadth-first-search-in-python/
To get an understanding of how Breadth First Search algorithm works in code.

http://scholarworks.rit.edu/cgi/viewcontent.cgi?article=7944&context=theses
Page 17.
For Symmetric Difference with Emptiness Testing.

To run code:

Each task is in its own file:
Task 1: Complementation.java
Task 2: Intersection.java
Task 3: Symmetric.java
Task 4: NonEmpty.java
Task 5:	Equivalence.java

Build and run as normal java file. When running, specify files to be used.
E.g. java Complementation "D1.txt"

The code will say if not enough/too many files were specified.